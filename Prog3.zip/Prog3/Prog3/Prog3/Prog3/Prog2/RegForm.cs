﻿// Program 3
// CIS 199-75
// Due: 3/7/2017
// Grading ID : C5761

// This application calculates the earliest registration date
// and time for an undergraduate student given their class standing
// and last name.
// Decisions based on UofL Fall/Summer 2017 Priority Registration Schedule


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Prog2
{
    public partial class RegForm : Form
    {
        public RegForm()
        {
            InitializeComponent();
        }

        // Find and display earliest registration time
        private void findRegTimeBtn_Click(object sender, EventArgs e)
        {
            const string DAY1 = "March 29";  // 1st day of registration
            const string DAY2 = "March 30";  // 2nd day of registration
            const string DAY3 = "March 31";  // 3rd day of registration
            const string DAY4 = "April 3";   // 4th day of registration
            const string DAY5 = "April 4";   // 5th day of registration
            const string DAY6 = "April 5";   // 6th day of registration

            // precondition: users must Enter a letter between A-Z 
            // post condition: users will resive the appropiate date and time for regestration. 

            // parallel array to match juniors and seniors students initials with the registration time.
            char[] juniorSineorLetters = { 'A', 'E', 'J', 'T', 'P' }; 
            string[] juniorSineorTimes = { "11:30 AM", "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM" }; 
           
            // parallel array to match sophomore and freshman students initials with the registration time.
            char[] SophmoreFreshmenLetters = { 'A', 'C', 'E', 'G', 'J', 'M', 'P', 'R', 'T', 'W' };
            string[] SophmoreFreshmenTimes = { "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM", "4:00 PM", "8:30 AM", "10:00 AM", "11:30 AM", "2:00 PM" };

            string lastNameStr;       // Entered last name
            char lastNameLetterCh;    // First letter of last name, as char
            string dateStr = "Error"; // Holds date of registration
            string timeStr = "Error"; // Holds time of registration
            bool isUpperClass;        // Upperclass or not?

            lastNameStr = lastNameTxt.Text;
            if (lastNameStr.Length > 0) // Empty string?
            {
                lastNameLetterCh = lastNameStr[0];   // First char of last name
                lastNameLetterCh = char.ToUpper(lastNameLetterCh); // Ensure upper case

                if (char.IsLetter(lastNameLetterCh)) // Is it a letter?
                {
                    isUpperClass = (seniorRBtn.Checked || juniorRBtn.Checked);

                    // Juniors and Seniors share same schedule but different days
                    if (isUpperClass)
                    {
                        if (seniorRBtn.Checked)
                            dateStr = DAY1;
                        else // Must be juniors
                            dateStr = DAY2;
                        bool found = false;
                        int index = juniorSineorLetters.Length - 1; // start from the end
                        while (index >= 0 && !found)
                        {
                            if (lastNameLetterCh >= juniorSineorLetters[index])
                                found = true;
                            else
                                --index;
                        }
                        if (found)
                            timeStr = juniorSineorTimes[index];
                        


                    }
                    // Sophomores and Freshmen
                    else // Must be soph/fresh
                    {
                        bool found = false;
                        int index = SophmoreFreshmenLetters.Length - 1; // start from the end 
                        while (index >= 0 && !found)
                        {
                            if (lastNameLetterCh >= SophmoreFreshmenLetters[index])
                                found = true;
                            else
                                --index;
                        }
                        if (found)
                            timeStr = SophmoreFreshmenTimes[index];

                        if (sophomoreRBtn.Checked)
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY4;
                            else // All other letters on previous day
                                dateStr = DAY3;
                        }
                        else // must be freshman
                        {
                            // C-O on one day
                            if ((lastNameLetterCh >= 'C') && // >= C and
                                (lastNameLetterCh <= 'O'))   // <= O
                                dateStr = DAY6;
                            else // All other letters on previous day
                                dateStr = DAY5;

                        }
                    }

                    // Output results
                    dateTimeLbl.Text = dateStr + " at " + timeStr;
                }

                else // First char not a letter
                    MessageBox.Show("Make sure last name starts with a letter");
            }


            else // Empty textbox
                MessageBox.Show("Enter a last name!");
        }
    }
}



