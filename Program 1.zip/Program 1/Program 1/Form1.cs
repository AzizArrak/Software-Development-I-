﻿// C5761
// program 1
// CIS 199-75
// Due Dates: 02/14/2017
// This program calculates the total cost of the paint based on the nuber of square feet that the user input.
// with the number of the gallons needed, the price of paint needed to finish the job
// the laber cost and the total cost of the paint based on the user input. 

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generateQuoteButton_Click(object sender, EventArgs e)
        {
            double squareFeet; //  number of square feet 
            int coatsOfPaint; //  the total cost of the paint needed
            double pricePerGallon = 9.99; // the paint price per gallon
            double totalSquareFeet; // the totl number of square feet
            double numberOfGallonsPaint; // the total number of gallon needed
            int feetPerGallon = 330; //  the number of feet can be paint in per gallon
            double hoursOfLaberPerGallon = 6; // the hours of laber needed to paint per gallon
            double totalPaintPrice; // the total paint price 
            double costOfLaberPerHour = 10.50; // the cost of laber for each hour
            double laberCost; // the total laber cost
            double totalPrice; // the total price to finish the job 
            double totalHoursOfLaber; // total hours needed to finish the job

            squareFeet = double.Parse(squareFeetTextBox.Text); // take the number of sq ft and parse it.
            coatsOfPaint = int.Parse(coatstOfPaintTextBox.Text); // take the cost of paint and parse it.
            pricePerGallon = double.Parse(pricePerGallonTextBox.Text);  // take the price per gallon and parse it. 

            totalSquareFeet = squareFeet * coatsOfPaint; // calculates the square feet to paint.
            totalSquareFeetLabel.Text = totalSquareFeet.ToString(); // Displays the number of square feet to paint.

            numberOfGallonsPaint = Math.Ceiling (totalSquareFeet / feetPerGallon); // calculates the total number of gallons needed.
            gallonNeededLabel.Text = numberOfGallonsPaint.ToString(); // Displays the total number of gallons needed 

            totalHoursOfLaber = Math.Round (((totalSquareFeet / feetPerGallon) * hoursOfLaberPerGallon), 1); //  calculates the total number of hours needed.
            hoursOfLaborLabel.Text = totalHoursOfLaber.ToString(); // Displays the total number of hours needed.

            totalPaintPrice = pricePerGallon * numberOfGallonsPaint; // calculates the total price of paint needed.
            paintCostLabel.Text = totalPaintPrice.ToString("c"); // Displays the total price of paint needed.

            laberCost = ((totalSquareFeet/feetPerGallon) * hoursOfLaberPerGallon) * costOfLaberPerHour; // calculates the total laber cost.
            laborCostLabel.Text = laberCost.ToString("c"); // Display the total laber cost.

            totalPrice = totalPaintPrice + laberCost; // calculates the total price to finish the job.
            totalCostLabel.Text = totalPrice.ToString("c"); // Displays the total price to finish the job.





        }
    }
}
