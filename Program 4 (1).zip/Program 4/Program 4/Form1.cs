﻿// ID: C5761
// Due Date: 04/25/2017
// Program 4 
// CIS 199-75
// This program represents packages delivered by Brown Parcel Service with three buttons to show details, send to UofL and send from UofL.
// Each GroundPackage object will keep track of some basic information.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_4
{
    public partial class program4 : Form
    {
        int originZip;    // origin zip code (not empty)
        int destinationZip;   // destination zip code (not empty)
        double length;   //length (non-negative)
        double width;   // width (non-negative)
        double height;  // height (non-negative)
        double weight; // weight(non-negative)

        // List to hold GroundPackage objects
        // Will be kept parallel with strings in Package ListBox
        private List<GroundPackage> packageList = new List<GroundPackage>();

        // Precondition:   Not specified
        // Postcondition: Form is constructed, ready to load

        public program4()
        {
            InitializeComponent();
        }
        
        // Precondition:  Add Package button is clicked.
        // Postcondition: If form data are valid, a new GroundPackage is added to list,
        //                fields are cleared and focus reset.

        private void addButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(originTextBox.Text, out originZip))
            {
                if (int.TryParse(destinationTextBox.Text, out destinationZip))
                {
                    if (double.TryParse(lengthTextBox.Text, out length))
                    {
                        if (double.TryParse(widthTextBox.Text, out width))
                        {
                            if (double.TryParse(heightTextBox.Text, out height))
                            {
                                if (double.TryParse(weightTextBox.Text, out weight))
                                {
                                    GroundPackage package = new GroundPackage(originZip, destinationZip,
                                        length, width, height, weight);
                                    packageOutputListBox.Items.Add(package.CalcCost().ToString("c"));   //adds package to the listBox.
                                    packageList.Add(package);
                                }
                                else
                                    MessageBox.Show("Please enter package weight");
                            }
                            else
                                MessageBox.Show("Please enter package height");
                        }
                        else
                            MessageBox.Show("Please enter package width");
                    }
                    else
                        MessageBox.Show("Please enter package length");
                }
                else
                    MessageBox.Show("Please enter destination zip");
            }
            else
                MessageBox.Show("Please enter origin zip");

            // clear the Text boxes.
            originTextBox.Clear();
            destinationTextBox.Clear();
            lengthTextBox.Clear();
            widthTextBox.Clear();
            heightTextBox.Clear();
            weightTextBox.Clear();
        }

        // Precondition: select the package from the listBox. 
        // Postcondition: when clicked will display a MessageBox providing all the details of the selected package 
      
        private void detailsButton_Click(object sender, EventArgs e)
        {
            if (packageOutputListBox.SelectedIndex > -1)
            {
                int index = packageOutputListBox.SelectedIndex; //finds selected package in list that's in listbox
                MessageBox.Show(packageList[index].ToString()); //displays in message box
            }
            else
                MessageBox.Show("Please select a package");
        }
        // Precondition: select the package from the listBox. 
        // Postcondition: when clicked will set the origin zip code of the selected package to 40292 
        //  and display a message indicating that.
        private void sendFromButton_Click(object sender, EventArgs e)
        {
            if (packageOutputListBox.SelectedIndex > -1)
            {
                int index = packageOutputListBox.SelectedIndex; //finds selected pkg in list that's in listbox
                packageList[index].OriginZip = 40292; //displays in msg box
                packageOutputListBox.Items[index] = packageList[index].CalcCost().ToString("c");
                MessageBox.Show("Origin Zip has been updated");
            }
            else
                MessageBox.Show("Please select a package.");
        }

        // Precondition: select the package from the listBox. 
        // Postcondition:when clicked will set the destination zip code of the selected package to 40292 
        //  and display a message indicating that.
        private void sendToButton_Click(object sender, EventArgs e)
        {
            if (packageOutputListBox.SelectedIndex > -1)
            {
                int index = packageOutputListBox.SelectedIndex; //finds selected package in list that's in listbox
                packageList[index].DestinationZip = 40292; //displays in message box
                packageOutputListBox.Items[index] = packageList[index].CalcCost().ToString("c");
                MessageBox.Show("Destination Zip has been updated");
            }
            else
                MessageBox.Show("Please select a package.");
        }
    
        // ListBox will return -1 for its SelectedIndex when no item has been selected yet.

    }
}
