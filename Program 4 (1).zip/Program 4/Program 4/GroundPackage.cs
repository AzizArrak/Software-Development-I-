﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program_4
{
    public class GroundPackage
    {
        // Consts
        public const int DEFAULT_ORGINZIP = 40202; // value used for inalid orgin zip.
        public const int DEFAULT_DESTINATIONZIP = 90210; // value used inalid destination zip
        public const double DEFAULT_OTHER_DATA = 1.0 ; // value used for inavild ( length, width, height, and weight)
        public const double DEFAULT_DIMENSION_VECTOR = .20; // holds ( length + Width + Height )
        public const double DEFAULT_DISTANCE_VACTOR = .5; // holds ( Zone Distance + 1) * ( Weight )

        // Backing fields
        private int _originZip;  // origin zip code (not empty)
        private int _destinationZip; // destination zip code (not empty)
        private double _length;     //length (non-negative)
        private double _width;     // width (non-negative)
        private double _height;    // height (non-negative)
        private double _weight;    // weight(non-negative)

        // constructor
        // precondition: all textboxes have information filled and are non-negative numbers.
        // postcondition: GroundPackage has been contructed with specified properties. 
        public GroundPackage(int originZip, int destinationzip, double length, double width, double height, double weight)
        {
            //set properties
            OriginZip = originZip;
            DestinationZip = destinationzip;
            Length = length;
            Width = width;
            Height = height;
            Weight = weight;
        }

        // originZip property
        public int OriginZip
        {
            // precondition: Not specified
            // postcondition: originZip returned, whatever is stored. 
            get
            {
                return _originZip;
            }

            // precondition: value not empty or all whitespace
            // postcondition: originZip has been set to specified; tests it.

            set
            {
                if (value > 00000 && value < 99999) // Valid; can't be negative number 
                    _originZip = value;
                else
                    _originZip = DEFAULT_ORGINZIP; // when inalid, set to the default value ( 40202 )
            }
        }

        // DestinationZip property.
        public int DestinationZip
        {
            // precondition:  Not specified
            // postcondition: return DestinationZip
            get
            {
                return _destinationZip;
            }

            // precondition: value not empty or all whitespace
            // postcondition: originZip has been set to specified; tests it.
            set
            {
                if (value > 00000 && value < 99999) // Valid; can't be negative number
                    _destinationZip = value;
                else
                _destinationZip = DEFAULT_DESTINATIONZIP; // when invalid, set to the default value ( 90210 )
            }
        }
        
        // Length property.
        public double Length
        {
            // Precondition:  Not specified
            // Postcondition: Return The Length
            get
            {
                return _length;
            }

            // Precondition:  value >= 0
            // Postcondition: The Length has been set to the specified value
            set
            {
                if (value >= 00000 && value <= 99999) // Valid; can't be negative number
                    _length = value;
                else
                    _length = DEFAULT_OTHER_DATA; // when invalid, set to the default value  1.0
            }
        }
        // Width property.
        public double Width
        {
            // Precondition:  Not specified
            // Postcondition: Return The Width
            get
            {
                return _width;
            }

            // Precondition:  value >= 0
            // Postcondition: The Width has been set to the specified value
            set
            {
                if (value >= 0) // Valid; can't be negative number
                    _width = value;
                else
                    _width = DEFAULT_OTHER_DATA; // when invalid, set to the default value  1.0          
            }
         }
        // Height property.
        public double Height
        {
            // Precondition:  Not specified
            // Postcondition: Ruturn The Height
            get
            {
                return _height;
            }

            // Precondition:  value >= 0
            // Postcondition: The Height has been set to the specified value
            set
            {
                if (value >= 0) // Valid; can't be negative number
                    _height = value;
                else
                    _height = DEFAULT_OTHER_DATA; // when invalid, set to the default value  1.0
            }
        }
        // Weight property
        public double Weight
        {
            // Precondition:  Not specified
            // Postcondition: Ruturn The Weight
            get
            {
                return _weight;
            }

            // Precondition:  value >= 0
            // Postcondition: The Weight has been set to the specified value
            set
            {
                if (value >= 0) // Valid; can't be negative number
                    _weight = value;
                else
                    _weight = DEFAULT_OTHER_DATA; // when invalid, set to the default value  1.0
            }
        }

        //ZoneDistance ( Read-Only ) property
        public int ZoneDistance
        {

            get
            {
                return Math.Abs((OriginZip / 10000) - (DestinationZip / 10000));
            }
        }

        // ToString method (Should always be included)
        // Precondition:  Not specified
        // Postcondition: A formatted string representing this CellPhone is returned

        // Precondition: method named CalcCost that returns a double and accepts no parameters. 
        // Postcondition: Not specified
        public double CalcCost()
        {
            return DEFAULT_DIMENSION_VECTOR * (Length + Width + Height) + DEFAULT_DISTANCE_VACTOR * (ZoneDistance + 1)*(Weight);
        }

        public override string ToString()
        {
            return "Origin : " + OriginZip.ToString("d5") + System.Environment.NewLine +
                "Destination : " + DestinationZip.ToString("d5") + System.Environment.NewLine +
                "Length : " + Length.ToString() + " in. " + System.Environment.NewLine +
                "Width : " + Width.ToString() + " in. " + System.Environment.NewLine +
                "Height : " + Height.ToString() + " in. " + System.Environment.NewLine +
                "Weight : " + Weight.ToString() + " lbs. ";
        }
    }
}

