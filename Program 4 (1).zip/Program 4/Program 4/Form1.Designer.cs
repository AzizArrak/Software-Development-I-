﻿namespace Program_4
{
    partial class program4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packageGroupBox = new System.Windows.Forms.GroupBox();
            this.addButton = new System.Windows.Forms.Button();
            this.lengthLabel = new System.Windows.Forms.Label();
            this.destinationLabel = new System.Windows.Forms.Label();
            this.originLabel = new System.Windows.Forms.Label();
            this.weightLabel = new System.Windows.Forms.Label();
            this.heightLabel = new System.Windows.Forms.Label();
            this.widthLabel = new System.Windows.Forms.Label();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.heightTextBox = new System.Windows.Forms.TextBox();
            this.widthTextBox = new System.Windows.Forms.TextBox();
            this.lengthTextBox = new System.Windows.Forms.TextBox();
            this.destinationTextBox = new System.Windows.Forms.TextBox();
            this.originTextBox = new System.Windows.Forms.TextBox();
            this.packageOutputListBox = new System.Windows.Forms.ListBox();
            this.detailsButton = new System.Windows.Forms.Button();
            this.sendFromButton = new System.Windows.Forms.Button();
            this.sendToButton = new System.Windows.Forms.Button();
            this.packageGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // packageGroupBox
            // 
            this.packageGroupBox.Controls.Add(this.addButton);
            this.packageGroupBox.Controls.Add(this.lengthLabel);
            this.packageGroupBox.Controls.Add(this.destinationLabel);
            this.packageGroupBox.Controls.Add(this.originLabel);
            this.packageGroupBox.Controls.Add(this.weightLabel);
            this.packageGroupBox.Controls.Add(this.heightLabel);
            this.packageGroupBox.Controls.Add(this.widthLabel);
            this.packageGroupBox.Controls.Add(this.weightTextBox);
            this.packageGroupBox.Controls.Add(this.heightTextBox);
            this.packageGroupBox.Controls.Add(this.widthTextBox);
            this.packageGroupBox.Controls.Add(this.lengthTextBox);
            this.packageGroupBox.Controls.Add(this.destinationTextBox);
            this.packageGroupBox.Controls.Add(this.originTextBox);
            this.packageGroupBox.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packageGroupBox.Location = new System.Drawing.Point(12, 12);
            this.packageGroupBox.Name = "packageGroupBox";
            this.packageGroupBox.Size = new System.Drawing.Size(278, 287);
            this.packageGroupBox.TabIndex = 4;
            this.packageGroupBox.TabStop = false;
            this.packageGroupBox.Text = "    Enter Package Data:";
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.addButton.Location = new System.Drawing.Point(86, 245);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(110, 31);
            this.addButton.TabIndex = 12;
            this.addButton.Text = "Add Package";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // lengthLabel
            // 
            this.lengthLabel.AutoSize = true;
            this.lengthLabel.Location = new System.Drawing.Point(83, 98);
            this.lengthLabel.Name = "lengthLabel";
            this.lengthLabel.Size = new System.Drawing.Size(58, 17);
            this.lengthLabel.TabIndex = 4;
            this.lengthLabel.Text = "Length  :";
            // 
            // destinationLabel
            // 
            this.destinationLabel.AutoSize = true;
            this.destinationLabel.Location = new System.Drawing.Point(4, 63);
            this.destinationLabel.Name = "destinationLabel";
            this.destinationLabel.Size = new System.Drawing.Size(137, 17);
            this.destinationLabel.TabIndex = 2;
            this.destinationLabel.Text = "Destination Zip Code :";
            // 
            // originLabel
            // 
            this.originLabel.AutoSize = true;
            this.originLabel.Location = new System.Drawing.Point(33, 26);
            this.originLabel.Name = "originLabel";
            this.originLabel.Size = new System.Drawing.Size(108, 17);
            this.originLabel.TabIndex = 0;
            this.originLabel.Text = "Origin Zip Code :";
            // 
            // weightLabel
            // 
            this.weightLabel.AutoSize = true;
            this.weightLabel.Location = new System.Drawing.Point(85, 201);
            this.weightLabel.Name = "weightLabel";
            this.weightLabel.Size = new System.Drawing.Size(56, 17);
            this.weightLabel.TabIndex = 10;
            this.weightLabel.Text = "Weight :";
            // 
            // heightLabel
            // 
            this.heightLabel.AutoSize = true;
            this.heightLabel.Location = new System.Drawing.Point(88, 170);
            this.heightLabel.Name = "heightLabel";
            this.heightLabel.Size = new System.Drawing.Size(53, 17);
            this.heightLabel.TabIndex = 8;
            this.heightLabel.Text = "Height :";
            // 
            // widthLabel
            // 
            this.widthLabel.AutoSize = true;
            this.widthLabel.Location = new System.Drawing.Point(92, 133);
            this.widthLabel.Name = "widthLabel";
            this.widthLabel.Size = new System.Drawing.Size(49, 17);
            this.widthLabel.TabIndex = 6;
            this.widthLabel.Text = "Width :";
            // 
            // weightTextBox
            // 
            this.weightTextBox.Location = new System.Drawing.Point(156, 198);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(100, 25);
            this.weightTextBox.TabIndex = 11;
            // 
            // heightTextBox
            // 
            this.heightTextBox.Location = new System.Drawing.Point(156, 167);
            this.heightTextBox.Name = "heightTextBox";
            this.heightTextBox.Size = new System.Drawing.Size(100, 25);
            this.heightTextBox.TabIndex = 9;
            // 
            // widthTextBox
            // 
            this.widthTextBox.Location = new System.Drawing.Point(156, 130);
            this.widthTextBox.Name = "widthTextBox";
            this.widthTextBox.Size = new System.Drawing.Size(100, 25);
            this.widthTextBox.TabIndex = 7;
            // 
            // lengthTextBox
            // 
            this.lengthTextBox.Location = new System.Drawing.Point(156, 95);
            this.lengthTextBox.Name = "lengthTextBox";
            this.lengthTextBox.Size = new System.Drawing.Size(100, 25);
            this.lengthTextBox.TabIndex = 5;
            // 
            // destinationTextBox
            // 
            this.destinationTextBox.Location = new System.Drawing.Point(156, 60);
            this.destinationTextBox.Name = "destinationTextBox";
            this.destinationTextBox.Size = new System.Drawing.Size(100, 25);
            this.destinationTextBox.TabIndex = 3;
            // 
            // originTextBox
            // 
            this.originTextBox.Location = new System.Drawing.Point(156, 24);
            this.originTextBox.Name = "originTextBox";
            this.originTextBox.Size = new System.Drawing.Size(100, 25);
            this.originTextBox.TabIndex = 1;
            // 
            // packageOutputListBox
            // 
            this.packageOutputListBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.packageOutputListBox.FormattingEnabled = true;
            this.packageOutputListBox.ItemHeight = 21;
            this.packageOutputListBox.Location = new System.Drawing.Point(316, 12);
            this.packageOutputListBox.Name = "packageOutputListBox";
            this.packageOutputListBox.Size = new System.Drawing.Size(166, 172);
            this.packageOutputListBox.TabIndex = 3;
            // 
            // detailsButton
            // 
            this.detailsButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.detailsButton.ForeColor = System.Drawing.Color.Red;
            this.detailsButton.Location = new System.Drawing.Point(354, 202);
            this.detailsButton.Name = "detailsButton";
            this.detailsButton.Size = new System.Drawing.Size(80, 33);
            this.detailsButton.TabIndex = 0;
            this.detailsButton.Text = "Details";
            this.detailsButton.UseVisualStyleBackColor = true;
            this.detailsButton.Click += new System.EventHandler(this.detailsButton_Click);
            // 
            // sendFromButton
            // 
            this.sendFromButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendFromButton.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.sendFromButton.Location = new System.Drawing.Point(330, 252);
            this.sendFromButton.Name = "sendFromButton";
            this.sendFromButton.Size = new System.Drawing.Size(130, 36);
            this.sendFromButton.TabIndex = 1;
            this.sendFromButton.Text = "Send from UofL";
            this.sendFromButton.UseVisualStyleBackColor = true;
            this.sendFromButton.Click += new System.EventHandler(this.sendFromButton_Click);
            // 
            // sendToButton
            // 
            this.sendToButton.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sendToButton.ForeColor = System.Drawing.Color.Green;
            this.sendToButton.Location = new System.Drawing.Point(316, 307);
            this.sendToButton.Name = "sendToButton";
            this.sendToButton.Size = new System.Drawing.Size(153, 41);
            this.sendToButton.TabIndex = 2;
            this.sendToButton.Text = "Send to UofL";
            this.sendToButton.UseVisualStyleBackColor = true;
            this.sendToButton.Click += new System.EventHandler(this.sendToButton_Click);
            // 
            // program4
            // 
            this.AcceptButton = this.addButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(508, 386);
            this.Controls.Add(this.detailsButton);
            this.Controls.Add(this.sendFromButton);
            this.Controls.Add(this.sendToButton);
            this.Controls.Add(this.packageOutputListBox);
            this.Controls.Add(this.packageGroupBox);
            this.Name = "program4";
            this.Text = "Program 4";
            this.packageGroupBox.ResumeLayout(false);
            this.packageGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox packageGroupBox;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label lengthLabel;
        private System.Windows.Forms.Label destinationLabel;
        private System.Windows.Forms.Label originLabel;
        private System.Windows.Forms.Label weightLabel;
        private System.Windows.Forms.Label heightLabel;
        private System.Windows.Forms.Label widthLabel;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.TextBox heightTextBox;
        private System.Windows.Forms.TextBox widthTextBox;
        private System.Windows.Forms.TextBox lengthTextBox;
        private System.Windows.Forms.TextBox destinationTextBox;
        private System.Windows.Forms.TextBox originTextBox;
        private System.Windows.Forms.ListBox packageOutputListBox;
        private System.Windows.Forms.Button detailsButton;
        private System.Windows.Forms.Button sendFromButton;
        private System.Windows.Forms.Button sendToButton;
    }
}

