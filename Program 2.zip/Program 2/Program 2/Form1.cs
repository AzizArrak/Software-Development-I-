﻿// ID: C5761
// Due Date: 03/9/2017
// Program 2
// CIS 199-75
// This program designed to determine the earliest time that continuing UofL undergraduate students may register for Fall 2017.
// students will input their last name on the text box and choose their classification from the radio buttons. 
// the program will test the inputs and assign specific day and time based on the UofL registration schedule.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_2
{
    public partial class Form1 : Form
    {
        string lastName; // holds students last name 
        char firstLatterOfLastName; // holds the first initial of the last name 
        string registrationDate; // holds the registration data 
        string registrationTime; // holds the registration time 
    
        public Form1()
        {
            InitializeComponent();
        }

        private void checkButton_Click(object sender, EventArgs e)
        {
            // when junior or senioe radio buttons checked 
            lastName = lastNameTxt.Text;
            firstLatterOfLastName = lastName[0]; 
            firstLatterOfLastName = char.ToUpper(firstLatterOfLastName); // returns the uppercase equivalent of (firstLatterOfLastName)
            if (juniorRadioButton.Checked || seniorRadioButton.Checked) // checks if the student junior or senioe.
            {
                if (firstLatterOfLastName <= 'D')
                {
                    registrationTime = "11:30 AM ";
                }

                else if (firstLatterOfLastName <= 'I')
                {
                    registrationTime = "2:00 PM ";
                }

                else if (firstLatterOfLastName <= 'O')
                {
                    registrationTime = "4:00 PM";
                }

                else if (firstLatterOfLastName <= 'S')
                {
                    registrationTime = "8:30 AM ";
                }

                else if (firstLatterOfLastName <= 'Z')
                {
                    registrationTime = "10:30 AM ";
                }
            }

            if (seniorRadioButton.Checked)
            {
                registrationDate = " Wedesday, March 29";
            }

            else if (juniorRadioButton.Checked)
            {
                registrationDate = " Thursday, March 30";
            }

        // when the sophomore or freshmen radio buttons checked
            if (sophRadioButton.Checked || freshmenRadioButton.Checked) 
            {
                if (firstLatterOfLastName <= 'B')
                {
                    registrationTime = "4:00 PM ";
                }
                else if (firstLatterOfLastName <= 'D')
                {
                    registrationTime = "8:30 AM ";
                }
                else if (firstLatterOfLastName <= 'F')
                {
                    registrationTime = "10:00 AM ";
                }
                else if (firstLatterOfLastName <= 'I')
                {
                    registrationTime = "11:30 AM ";
                }
                else if (firstLatterOfLastName <= 'L')
                {
                    registrationTime = "2:00 PM ";
                }
                else if (firstLatterOfLastName <= 'O')
                {
                    registrationTime = "4:00 PM ";
                }
                else if (firstLatterOfLastName <= 'Q')
                {
                    registrationTime = "8:30 AM ";
                }
                else if (firstLatterOfLastName <= 'S')
                {
                    registrationTime = "10:00 AM ";
                }
                else if (firstLatterOfLastName <= 'V')
                {
                    registrationTime = "11:30 AM ";
                }
                else if (firstLatterOfLastName <= 'Z')
                {
                    registrationTime = "2:00 PM ";
                }
            }

            if (freshmenRadioButton.Checked) // assign the date for freshmen students 
            {
                if (firstLatterOfLastName >= 'C' || firstLatterOfLastName >= 'O')
                {
                    registrationDate = "Wedesday, April 5";
                }
                if (firstLatterOfLastName <= 'B' || firstLatterOfLastName >= 'P')
                {
                    registrationDate = " Tuesday, April 4 ";
                }
            }

            if (sophRadioButton.Checked) // assign the date for sophomore students
            {
                if (firstLatterOfLastName >= 'C' || firstLatterOfLastName >= 'O')
                {
                    registrationDate = "Monday, April 3";
                }
                if (firstLatterOfLastName <= 'B' || firstLatterOfLastName >= 'P')
                {
                    registrationDate = " Friday, March 31 ";
                }
            }
            // displays the outcome on outcome label 
            outPutLabel.Text = registrationDate + "" + "\n" + registrationTime;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            outPutLabel.Text = ""; // clear the outcome label 
            lastNameTxt.Clear(); // clear the last name text box 
        }
    }
}
